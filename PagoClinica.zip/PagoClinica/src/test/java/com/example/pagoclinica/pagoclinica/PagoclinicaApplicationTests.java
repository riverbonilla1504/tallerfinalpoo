package com.example.pagoclinica.pagoclinica;

import javax.swing.Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagoclinicaApplicationTests {
	public static void main(String[] args) {
		SpringApplication.run(PagoclinicaApplication.class, args);
	}

	@Test
	void contextLoads() {
	}

}
